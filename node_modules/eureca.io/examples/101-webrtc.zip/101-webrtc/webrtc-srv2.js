// This script runs under node, and `serverless-webrtc.html` runs inside
// a browser.
// Usage: `node serverless-webrtc.js` or `node serverless-webrtc.js --create`.
var webrtc = require('wrtc');
var readline = require('readline');
var ansi = require('ansi');
var cursor = ansi(process.stdout);



var http = require('http');
var Eureca = require('eureca.io');

var server = http.createServer();
var eurecaServer = new Eureca.Server();

eurecaServer.attach(server);


var rtcList = [];
eurecaServer.exports.signal = function (offer) {
    var context = this;
    context.async = true;
    console.log('Received offer', offer);
	var srv = new rtcServer();
	rtcList.push(srv);
    srv.getOffer(offer, function(desc) {
		console.log('sending answer');
		context.return(JSON.stringify(desc));
    });    
}

server.listen(8000);


var rtcServer = function() {
	pc = null;
	offer = null;
	answer = null;
	this.channel = null;
	var _this = this;
	
	this.getOffer = function(pastedOffer, callback) {
	  data = JSON.parse(pastedOffer);
	  offer = new webrtc.RTCSessionDescription(data);
	  answer = null;

	  pc = new webrtc.RTCPeerConnection(pcSettings);
	  pc.onsignalingstatechange = onsignalingstatechange;
	  pc.oniceconnectionstatechange = oniceconnectionstatechange;
	  pc.onicegatheringstatechange = onicegatheringstatechange;
	  pc.onicecandidate = function(candidate) {
		// Firing this callback with a null candidate indicates that
		// trickle ICE gathering has finished, and all the candidates
		// are now present in pc.localDescription.  Waiting until now
		// to create the answer saves us from having to send offer +
		// answer + iceCandidates separately.
		if (candidate.candidate == null) {
		  //doShowAnswer();
		  if (typeof callback == 'function') callback(pc.localDescription);
		}
	  }
	  doHandleDataChannels();
	}

	function doShowAnswer() {
	  answer = pc.localDescription;
	  console.log("\n\nHere is your answer:");
	  console.log(JSON.stringify(answer) + "\n\n");
	}

	function doCreateAnswer() {
	  pc.createAnswer(doSetLocalDesc, doHandleError);
	}

	function doSetLocalDesc(desc) {
	  answer = desc;
	  pc.setLocalDescription(desc, undefined, doHandleError);
	};

	function doHandleDataChannels() {
	  var labels = Object.keys(dataChannelSettings);
	  pc.ondatachannel = function(evt) {
		var channel = evt.channel;
		_this.channel = channel;
		
		var label = channel.label;
		pendingDataChannels[label] = channel;
		//channel.binaryType = 'arraybuffer';
		channel.onopen = function() {
		  dataChannels[label] = channel;
		  delete pendingDataChannels[label];
		  if(Object.keys(dataChannels).length === labels.length) {
			console.log("\nConnected!");
			
			inputLoop();
		  }
		};
		channel.onmessage = function(evt) {
		  data = JSON.parse(evt.data);
		  cursor.blue();
		  console.log(data.message);
		  inputLoop();
		};
		channel.onerror = doHandleError;
	  };

	  pc.setRemoteDescription(offer, doCreateAnswer, doHandleError);
	}
}







/* 1. Global settings, data and functions. */
var dataChannelSettings = {
  'reliable': {
        ordered: true,
        maxRetransmits: 0
      },
};

var pcSettings = [
  {
    iceServers: [{url:'stun:stun.l.google.com:19302'}]
  },
  {
    'optional': [{DtlsSrtpKeyAgreement: false}]
  }
];

var pendingDataChannels = {};
var dataChannels = {}


var rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function doHandleError(error) {
  throw error;
}

function onsignalingstatechange(state) {
  //console.info('signaling state change:', state);
}
function oniceconnectionstatechange(state) {
  //console.info('ice connection state change:', state);
}
function onicegatheringstatechange(state) {
  //console.info('ice gathering state change:', state);
}

function inputLoop() {
  cursor.green();
  rl.question("> ", function(text) {
	for (var i=0; i<rtcList.length; i++)
	{
		rtcList[i].channel.send(JSON.stringify({message: text}));
	}
    inputLoop();
  });
}

/* 2. This code deals with the --join case. */




